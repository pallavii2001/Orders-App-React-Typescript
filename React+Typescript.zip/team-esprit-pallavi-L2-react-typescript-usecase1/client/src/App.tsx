
import './App.css';
import Routerindex from './Router/Router';

function App() {
  return (

    <Routerindex/>
  );
}

export default App;
